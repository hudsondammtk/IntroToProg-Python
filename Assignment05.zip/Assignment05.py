# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Tristan Hudson-Damm, 11/12/2018, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

objFileName = open("C:\_PythonClass\Module05\Todo.txt", "r")
# Here, we open our file with the "read" appendix so that we can pull in our text data.
strData = ""
dicRow = {}
FirstTable = []
# These variables are now assigned to be a string, dictionary, and list, respectively.
ID = 0
# ID will be important when the user is prompted to specify a chore's number in the list.

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
for line in objFileName:
    ID += 1
    # Here, we change the ID to 1 on the first read-through, then it will become 2 the second time around.
    # This way, the ID value in dicRow will match the order of the first and second rows.
    strData = line.split(",")
    # Splitting on the comma means that the chore and priority will be read as separate items.
    dicRow = {'Chore Number': ID, 'Chore': strData[0], 'Importance': strData[1].strip("\n")}
    # Assigning a key and value to each row; strData looks for the chore [0] and the value [1].
    FirstTable.append(dicRow)
    # Here, we move our dictionary row into a table and print it to the user below.
print (FirstTable)


# Step 2 - Display a menu of choices to the user
while (True):
# This ensures that our program will continue looping back to the menu after the user selects options 1-4.
    if len(FirstTable) == 0:
        print ("Your chore list is currently empty.")
        # This is just so that the user doesn't see [] if they ask for their data after deleting several items.
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print (FirstTable)
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        new_chore = input("What is the new chore you'd like to add? ")
        new_importance = input("How important is this chore? Type low, medium, or high: ")
        # Assigns two variables to the user input
        new_dict = {"Chore Number": ID + 1, "Chore": new_chore, "Importance": new_importance}
        # Takes those two variables and orders them into a new dictionary, much like line 66.
        # ID + 1 is there so that the ID of the chore matches what the user prompt will indicate.
        FirstTable.append(new_dict)
        ID += 1
        # Increasing the value of ID here means that it will update with each iteration of option 2.

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        removed_chore = int(input("Please enter the number of the chore you want to remove: "))
        removed_chore -= 1
        # Subtracting 1 from our variable so that the list's values remain mutable if we want to add or delete more.
        del FirstTable[removed_chore]
        # del() works instead of remove() because remove only looks for the first variable instance in the list.
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objFileName = open("C:\_PythonClass\Module05\Todo.txt", "w")
        # Here, we open the file with the write appendix this time, so that we can add our data.
        # I used write instead of append because we don't want the same chores to be repeated,
            # so this method means that our first two lines will be written over by themselves in the new format.
        objFileName.write (str((FirstTable)))
        objFileName.close()
        # .close() saves the data to our text file.
        print ("Your new list has been saved.")
    elif (strChoice == '5'):
        break  # and Exit the program

