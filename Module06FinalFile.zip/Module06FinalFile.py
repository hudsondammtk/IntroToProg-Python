#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   Tristan Hudson-Damm, 11/14/2018, Added and modified code to complete assignment 06

#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

#objFileName = "C:\_PythonClass\Todo.txt"
#strData = ""
#dicRow = {}
lstTable = [] #I managed to avoid using the global "strData" and "dicRow" variables,
              # but I couldn't make the program work without globally defining lstTable.

class To_Do_Functions(): #Defining a class to hold our functions
    @staticmethod #Specifies that the function can be called upon by name later
    def read_text(X): #Most of this code is from Summer Rae's provided template;
        for line in X:#The changes come from moving and restructuring the code to fit into functions
            strData = line.split(",")
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            lstTable.append(dicRow)
        X.close() #read_text takes an "X" argument, which we're using to specify the file location
                  # at the end of the code, when we call the function
    @staticmethod
    def choice_1(): #This "display list" function doesn't need to include the
                    # "if input() == 1/2/3/4 code that it did in the last assignment.
                    #Instead, we'll later check if the strChoice variable matches the assigned function.
            print("******* The current items ToDo are: *******")
            for row in lstTable:
                print(row["Task"] + "(" + row["Priority"] + ")")
            print("*******************************************")

    @staticmethod
    def choice_2():
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow) #This is another spot that I would have liked to avoid using a global variable.

    @staticmethod
    def choice3():
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):
                del lstTable[intRowNumber]
                blnItemRemoved = True
            intRowNumber += 1
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    @staticmethod
    def choice_4():
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open("C:\_PythonClass\Todo.txt", "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

    @staticmethod
    def menu(): #Here is the function in which we will check the user's input, and compare it to our list
                # of previously defined functions. All of this is still nested under the To_Do_Functions class.
        while(True):
            print("******* The current items ToDo are: *******")
            for row in lstTable:
                print(row["Task"] + "(" + row["Priority"] + ")")
            print("*******************************************")
            print ("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            print()
            if (strChoice.strip() == '1'): #This section is much easier to read and edit this time around,
                To_Do_Functions.choice_1() # since we only have to call on our functions instead of defining the entire
            elif(strChoice.strip() == '2'):# if-elif-else block for each input choice.
                To_Do_Functions.choice_2()
            elif(strChoice == '3'):
                To_Do_Functions.choice3()
            elif (strChoice == '4'):
                To_Do_Functions.choice_4 ()
            elif (strChoice == '5'):
                break
            else:
                print ("Please enter a menu option 1-5.")

To_Do_Functions.read_text(open("C:\_PythonClass\Todo.txt", "r")) #We break out of the functions' class, and call
                                                                 # upon the functions by their class and name.
                                                                 #We're specifying the paramter in read_text and passing
                                                                 # it to "X" in the function.
To_Do_Functions.menu()

