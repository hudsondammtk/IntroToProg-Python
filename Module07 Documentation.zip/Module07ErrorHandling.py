# -------------------------------------------------------------- #
# Title: Module 07 Error Handling
# Creator: Tristan Hudson-Damm
# Date: 11/19/2018
# Changelog:
#   Tristan Hudson-Damm, 11/19/2018, created script
#----------------------------------------------------------------#

import pickle
import sys #First, we import the sys module so that we can use its exc_info function.
def additiontest(): #I'm defining this test as a function for ease of repetition,
                    #   since we can run it several times to look for different errors.

    try: # This is the start of our try block; lines 14 through 19 will attempt to run normally.
        x = int(input("Enter a number: ")) # Assigning a variable to a user's integer input.
        y = int(input("Enter a second number, and we'll calculate the sum, difference, product, and quotient: "))
        print ("The sum of your entries is " + str(x + y))
        print("The sum of your entries is " + str(x - y))
        print("The sum of your entries is " + str(x * y))
        print("The sum of your entries is " + str(x / y))
    except: # If the program encountered a problem within the try block, the except block will print out a list of
            #   error information, which we pulled from the 3-item list in sys.exc_info. This list contains error
            #   information about the error's type, value, and traceback call.
        print ("\nThe following errors occured: \n")
        print ("Type error: " + (str(sys.exc_info()[0])))
        print("Value error: " + (str(sys.exc_info()[1])))
        print("Traceback error: " + (str(sys.exc_info()[2])) + "\n")
while True:
    user_input = input("Type 'start' to run the program or enter to quit: ").upper()
    if user_input == str("START"):
        additiontest()
    else:
        break