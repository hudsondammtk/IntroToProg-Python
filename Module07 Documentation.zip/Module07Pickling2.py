# -------------------------------------------------------------- #
# Title: Module 07 Pickling
# Creator: Tristan Hudson-Damm
# Date: 11/19/2018
# Changelog:
#   Tristan Hudson-Damm, 11/19/2018, created script
#----------------------------------------------------------------#

import pickle # Importing the 'pickle' module for use later in the script.

contact_list = open("C:\_PythonClass\ContactList", "wb") # This line opens a file for binary writing, as
                                                         # shown by 'wb.' wb notifies the program that we're
                                                         # writing to binary instead of writing like we would for a
                                                         # text file.

names_list = ["John", "Sarah", "Kelly"] # Defining a list for our program, currently consisting of 3 items.
def print_names():
    print ("Here are the names in your file:")
    for item in names_list:
        print (item)
    print ("\n")
print_names() # This block is a simple function to print out whatever is currently in the list on descending lines.

while True:
    user_response = input("Do you want to add a name to the contacts list? Press y for yes or n to exit: ").upper()
    if user_response == "Y":
        new_name = input("Please enter the name of the contact you wish to add: ")
        names_list.append(new_name)
        print ("The contact has been saved.")
    elif user_response == "N":
        print ("Pickling file...")
        print ("Exiting program.\n")
        break
    # This while loop contains a script much like we've seen in recent assignments, in which a user can add names
    # to a contacts list.
pickle.dump(names_list, contact_list) # pickle.dump is similar in concept to X.write, where X is a file name.
                                      # The difference is that pickle.dump is writing the data to a binary file
                                      #     instead of a text file.
contact_list.close() # We close the list to save our data.

contact_list_2 = open("C:\_PythonClass\ContactList", "rb") # "rb" on this line specifies that we're going to
                                                           #    read the file in binary.
names_list_2 = pickle.load(contact_list_2) # pickle.load pulls the information out of our binary file in readmode.
def print_names_2():
    print ("Unpickling file...")
    print ("Here are the names in your file:")
    for item in names_list_2:
        print (item) # This function just prints out the contents of our file for test purposes.
    print ("\n")
contact_list_2.close()

print_names()
print_names_2()


